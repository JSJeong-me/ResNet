
remocon - v1 2021-10-14 10:27pm
==============================

This dataset was exported via roboflow.ai on October 14, 2021 at 1:30 PM GMT

It includes 880 images.
3 are annotated in folder format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 320x320 (Stretch)

The following augmentation was applied to create 2 versions of each source image:
* Random rotation of between -15 and +15 degrees


