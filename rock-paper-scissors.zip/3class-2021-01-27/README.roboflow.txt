
rock-paper-scissors - v2 2021-01-27 11:17am
==============================

This dataset was exported via roboflow.ai on January 27, 2021 at 2:18 AM GMT

It includes 887 images.
3 are annotated in folder format.

The following pre-processing was applied to each image:
* Resize to 224x224 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically


